[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/KqXfVlK9)
# ASSIGNMENT 4 - KONTOVERWALTUNG

---
## Überblick

Assignment 4 ist ein Java Programm, welches die Verwaltung von Konten ermöglicht.
Hierbei werden Konten, verschieden Kontotypen (Girokonto, Kreditkonto, Sparkonto) und Kontobewegungen (Einzahlung, Auszahlung, Überweisung) verwaltet.

Es gibt mehrere Benutzer, die jeweils mehrere Konten besitzen können. Jedes Konto hat die üblichen Identifikationsmerkmale wie IBAN, BIC, Kontostand, etc.

Die Konten werden zu Testzwecken aus einer zur Verfügung Datei eingelesen und in einer Datenstruktur gespeichert.
Die Kontobewegungen sowie das Erstellen von Konten und Login/Logout werden über die Konsole als Commands mit zugehörigen Parametern eingelesen und verarbeitet.

---
## Beurteilungsschema

| Beurteilung        |Anforderungen|
|:-------------------| :- |
| **Sehr Gut**       |Grundlegende Teilaufgaben vollständig erfüllt **und** erweiterte Teilaufgaben vollständig erfüllt.|
| **Gut**            |Grundlegende Teilaufgaben vollständig erfüllt **und** erweiterte Teilaufgaben überwiegend erfüllt.|
| **Befriedigend**   |Grundlegende Teilaufgaben vollständig erfüllt **oder** grundlegende Teilaufgaben überwiegend erfüllt und zumindest Ansätze bei allen erweiterten Teilaufgaben.|
| **Genügend**       |Grundlegende Teilaufgaben überwiegend erfüllt.| 
| **Nicht genügend** |Grundlegende Teilaufgaben **nicht** überwiegend erfüllt.| < 50 % |
---

## Spezifikationen

- **Alle Ausgaben erfolgen über System.out**
- **Keinerlei Ausgaben erfolgen über System.err**
- **Halte dich an den StyleGuide**
- **Bitte befolge die Anweisungen zur Ausgabe _genau_, da die Test Cases selbst bei kleinen Fehlern (z.B. ein Leerzeichen zu viel oder zu wenig) fehlschlagen!**
- **Verwende die in den Lernzielen aufgezählten Konzepte, ansonsten werden bei der Bewertung Punkte abgezogen**

Diese Aufgabenstellung beinhaltet Platzhalter bei den Ausgabeformaten.

```In diesem Beispiel wird ein Wert eingelesen: ```
> nicht auf das Leerzeichen zwischen `:` und dem einzugebenden Wert vergessen!

```In diesem Beispiel wird folgender Wert ausgegeben: <ausgabewert>```

Ein Platzhalter ist immer mit `<>` gekennzeichnet und soll bei Eingaben oder Ausgaben nicht auf der Konsole ausgegeben werden.
Bei Ausgabewerten soll der jeweilige Wert, der dafür berechnet oder verarbeitet wurde, statt dem Platzhalter angezeigt werden.

---
## Hilfsmittel
### Erlaubt sind:
- Internet (Google, Foren, Teachin-Sites, …)
- Alte, selbstprogrammierte Projekte
- Trainer um Hilfe fragen :D
### Nicht erlaubt sind:
- Gruppenarbeit
- Plagiate (siehe StyleGuide)
- Von ChatGPT erstellter Code, es sei denn er erfüllt die Anforderungen von Plagiaten
---
## Lernziele
Es wurde eine Aufgabenstellung aus folgenden Kapiteln gewählt:

- Alles bisherige
- Java OOP
- Java File I/O
- Java HashMap
- Java ArrayList
- Java Super Keyword
- Java Inheritance (Vererbung)
---
## Aufgabenstellung

In Assignment 4 (A4) soll ein Programm zur Verwaltung von Konten erstellt werden.
Bitte beachte, dass die Aufgabenstellung **genau** durchgelesen werden muss,
um das Assignment zu bestehen, da die Outputs
sonst nicht mit dem erwarteten Output übereinstimmen.

A4 besteht aus 3 Teilen. Ich empfehle die Teile in der angegebenen Reihenfolge zu bearbeiten, bevor mit dem nächsten Teil
begonnen wird. Die Teile sind so konzipiert, dass sie aufeinander aufbauen.

- [Design Document](./assignment_descriptions/Design_Document.md)
- [Milestone 1 - Basis](./assignment_descriptions/Milestone_1.md)
    - > Wichtig: Um Milestone 1 zu schaffen darf nicht auf die [Error Messages](../assignment_descriptions/Milestone_2.md#error-messages) vergessen werden!
      Diese sind zwar unter [Milestone 2](./assignment_descriptions/Milestone_2.md) abgespeichert, allerdings gehören die Error Messages der Commands
      die in Milestone 1 zu machen sind auch zu Milestone 1 dazu. Die Errormessages wurden der Einfachheit halber in Milestone 2 geschrieben.
- [Milestone 2 - Erweiterung und Bonus](./assignment_descriptions/Milestone_2.md)

### Aufgabenstellungs-spezifische Spezifikationen

Man muss bei Assignment 4 mindestens 50% der Punkte erreichen. Das nicht erreichen dieser
50% führt zu einer negativen Beurteilung des Fachs Java Basics.
> ACHTUNG: Eine negative Beurteilung wirkt sich nicht automatisch negativ auf eure Laufbahn oder andere Gegenstände aus.
> Es zeigt nur, dass ihr die Grundkompetenzen in Java nicht erfüllt.
> Es gibt ausreichend Chancen um sich eine positive Beurteilung zu erarbeiten. Einschließlich Assignment 5, welches
> als Ersatz für A4 dienen kann.

Die folgenden Konzepte (Lernziele) **müssen** in eurem Programm verwendet werden:
- File I/O
- HashMap
- Inheritance (Vererbung)
- Super Keyword

## Benotung
Assignment 4 ist gesamt 35 Punkte wert. Die Aufteilung der Punkte ist wie folgt:

|  Unteraufgabe   | Punkte |                                   Notiz                                   |
|:---------------:|:------:|:-------------------------------------------------------------------------:|
| Design Document |   0    | verpflichtend abzugeben sonst gibt es 0 Punkte auf das gesamte Assignment |        
|   Milestone 1   |   30   |                 21 Punkte Funktion + 9 Punkte StyleGuide                  |        
|   Milestone 2   |   20   |                 14 Punkte Funktion + 6 Punkte StyleGuide                  |        
|      Bonus      |   10   |                  7 Punkte Funktion + 3 Punkte StyleGuide                  |        

> Durch diese Aufteilung ist es grundsätzlich möglich, dass A4 mit Milestone 1 alleine bestanden wäre.
>
> Allerdings müssen dabei alle Milestone 1 Anforderungen vollständig erfüllt sein und der StyleGuide muss eingehalten werden.

