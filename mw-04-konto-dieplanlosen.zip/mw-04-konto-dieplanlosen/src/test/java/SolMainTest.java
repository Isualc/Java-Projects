import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.io.*;
import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.assertEquals;

class SolMainTest {
  private final InputStream systemIn = System.in;
  private final PrintStream systemOut = System.out;

  private ByteArrayInputStream testIn;
  private ByteArrayOutputStream testOut;

  @BeforeEach
  void setUp() {
    testOut = new ByteArrayOutputStream();
    System.setOut(new PrintStream(testOut));
    testIn = null; // Initialize testIn variable
  }

  private void provideInput(String data) {
    testIn = new ByteArrayInputStream(data.getBytes());
    System.setIn(testIn);
  }

  private String getOutput() {
    return testOut.toString().trim().replace("\r","");
  }

  @AfterEach
  void tearDown() {
    System.setIn(systemIn);
    System.setOut(systemOut);
  }

  @Test
  public void testCase0() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc0.txt");
  }

  @Test
  public void testCase1() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc1.txt");
  }

  @Test
  public void testCase2() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc2.txt");
  }

  @Test
  public void testCase3() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc3.txt");
  }

  @Test
  public void testCase4() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc4.txt");
  }

  @Test
  public void testCase5() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc5.txt");
  }

  @Test
  public void testCase6() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc6.txt");
  }

  @Test
  public void testCase7() {
    testOutputForInputFile("src/test/resources/milestone_1_inputs/tc7.txt");
  }

  //Milestone 2 tests
  @Test
  public void testCase8() {
    testOutputForInputFile("src/test/resources/milestone_2_inputs/tc8.txt");
  }

  @Test
  public void testCase9() {
    testOutputForInputFile("src/test/resources/milestone_2_inputs/tc9.txt");
  }

  @Test
  /**
   * This method is used to test the output of the student program against the output of the solution program.
   * @param filePath The path to the test case folder.
   */
  public void testOutputForInputFile(String filePath) {
    // Setup inputs
    provideInput(inFromTextFile(filePath));
    String expectedFromSolution = "";
    // Starts solution program
    Process proc;
    try {
      proc = Runtime.getRuntime().exec("java -jar test/resources/mw_04_konto_mvn-1.0-SNAPSHOT.jar");

      OutputStream solStdIn = proc.getOutputStream();

      solStdIn.write(inFromTextFile(filePath).getBytes());
      solStdIn.flush();
      solStdIn.close();

      InputStream solStdOut = proc.getInputStream();
      // InputStream err = proc.getErrorStream();
      // Get expected output
      expectedFromSolution = new String(solStdOut.readAllBytes()).trim().replace("\r", "");

    } catch (IOException e) {
      expectedFromSolution = "There was an error in the tutors testing. Please contact your tutor for help";
      throw new RuntimeException(e);
    }



    // Reset output
    setUp();
    // Setup inputs
    provideInput(inFromTextFile(filePath));
    // Starts student program
    //Main.main(new String[0]);
    Main.main(new String[0]);
    // Get actual output
    String actualOut = getOutput().replaceAll("$\n", "");
    // Compare outputs
    assertEquals(expectedFromSolution, actualOut);
  }

  /**
   * This method is used to read the content of a file and return it as a String.
   * @param filePath The path to the file.
   * @return The content of the file as a String.
   */
  public String inFromTextFile(String filePath) {
    File currentFile = new File(filePath);
    StringBuilder in = new StringBuilder();
    try {
      Scanner sc = new Scanner(currentFile);
      while (sc.hasNextLine()) {
        in.append(sc.nextLine());
        in.append("\n");
      }
      sc.close();

    } catch (FileNotFoundException e) {
      throw new RuntimeException(e);
    }
    return in.toString();
  }
}