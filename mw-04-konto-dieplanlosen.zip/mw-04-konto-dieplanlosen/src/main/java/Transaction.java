/**
* Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the transaction object.
 */
public class Transaction {
    /**
     * -----------------------------------------------------------------------------------------------------
     * Attributes for the Transaction class.
     */
    private String outgoingIban;
    private String incomingIban;
    private double amount;
    private String transactionType;

    /**
     * -----------------------------------------------------------------------------------------------------
     * Constructs a new Transaction.
     * @param outgoingIban The IBAN from which the funds are withdrawn.
     * @param incomingIban The IBAN to which the funds are deposited.
     * @param amount The amount of money transferred in the transaction.
     * @param transactionType The type of transaction (e.g., transfer, payment).
     */
    public Transaction(String outgoingIban, String incomingIban, double amount, String transactionType) {
        this.outgoingIban = outgoingIban;
        this.incomingIban = incomingIban;
        this.amount = amount;
        this.transactionType = transactionType;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * Getter methods for the Transaction class.
     */
    public String getOutgoingIban() {
        return outgoingIban;
    }

    public String getIncomingIban() {
        return incomingIban;
    }

    public double getAmount() {
        return amount;
    }

    public String getTransactionType() {
        return transactionType;
    }


}
