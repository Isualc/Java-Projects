/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the person object.
 */
public class Person {
    /**------------------------------------------------------------------------------------------------------
     * Attributes for the Person class.
     */
    private String firstName;
    private String lastName;
    private String birthday;
/**------------------------------------------------------------------------------------------------------
 * Constructor for the Person class.
 * @param firstName The first name of the person.
 * @param lastName The last name of the person.
 * @param birthday The birthday of the person.
 * */
    public Person (String firstName, String lastName, String birthday){
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthday = birthday;
    }

    /**------------------------------------------------------------------------------------------------------
     * Getter methods for the Person class.
     */

    public String getFirstName(){
        return firstName;
    }
    public String getLastName(){
        return lastName;
    }
    public String getBirthday(){
        return birthday;
    }


}
