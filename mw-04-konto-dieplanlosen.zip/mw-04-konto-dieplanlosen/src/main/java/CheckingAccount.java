/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the checking account object.
 */
public class CheckingAccount extends Account {
    /**
     * -----------------------------------------------------------------------------------------------------
     * Constructs a new CheckingAccount.
     * @param owner The owner of the checking account.
     * @param iban The international bank account number.
     * @param overdraftLimit The overdraft limit for the checking account.
     */
    public CheckingAccount(Person owner, String iban, double overdraftLimit) {
        super(owner, iban, "CheckingAccount",0, overdraftLimit);
    }
}

