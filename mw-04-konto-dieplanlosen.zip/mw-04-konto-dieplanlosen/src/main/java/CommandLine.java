import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Scanner;
import java.util.Locale;
import java.time.format.ResolverStyle;

/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the command line object.
 */

public class CommandLine {
    public static Scanner scanner = new Scanner(System.in);

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method gets the filename from the user.
     */
    public static String getFileName() {
        String fileName;
        while (true) {
            System.out.println("Enter a filename :");
            fileName = scanner.nextLine();

            if (!fileName.endsWith(".txt")) {
                System.out.println("ERROR: A the filename must be end with \" .txt\"");
                continue;
            }
            break;
        }
        return "files/" + fileName;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method reads the command from the user.
     */

    public static Command readCommand() {

        String input;

        while (true) {
            System.out.print("Enter Command: ");
            input = scanner.nextLine().trim();



           /* if (input.equalsIgnoreCase("exit")) {
                System.out.println("INFO: Exiting program...");
                System.exit(0);
            }*/
            if (!input.isEmpty()) {
                return parseCommand(input);
            }
        }
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method parses the command from the user.
     */
    private static Command parseCommand(String input) {

        String[] fullCommand = input.split(" ");
        String commandType = fullCommand[0].toLowerCase();
        String[] parameters = new String[fullCommand.length - 1];
        int a = 0;
        for (int i = 0; i < fullCommand.length; i++) {
            if (i == 0)
                continue;
            parameters[a] = fullCommand[i];
            a++;
        }
        return new Command(commandType, parameters);
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method gets and validates the user's birthdate.
     */
    public static boolean getBirthDay(String input) {
        String[] arrDay = input.split("\\.");


        try {
            int day = Integer.parseInt(arrDay[0]);
            int month = Integer.parseInt(arrDay[1]);
            int year = Integer.parseInt(arrDay[2]);
            LocalDate birthDate;

            // Check if the input has integers in the correct positions (DD.MM.YYYY)
            if (!input.matches("\\d{2}\\.\\d{2}\\.\\d{4}")) {
                System.out.println("ERROR: Invalid date of birth! Use the following format (DD.MM.YYY).");
                return false;
            }
            birthDate = LocalDate.of(year, month, day);
            if (birthDate.isAfter(LocalDate.now())) {
                System.out.println("ERROR: Invalid date of birth! The given date cannot be in the future.");
                return false;
            }

            Period age = Period.between(birthDate, LocalDate.now());
            if (age.getYears() < 18) {
                System.out.println("ERROR: Invalid date of birth! You must be 18 years or older to open an account.");
                return false;
            }

        } catch (DateTimeException n) {
            System.out.println("ERROR: Invalid date of birth! The given date does not exist.");
            return false;
        } catch (NumberFormatException n) {
            System.out.println("ERROR: Invalid date of birth! Please only enter valid integers, seperated by dots (.) .");
            return false;
        }
        return true;
    }
}

