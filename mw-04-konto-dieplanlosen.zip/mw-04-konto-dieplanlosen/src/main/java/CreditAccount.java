/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the credit account object.
 */
public class CreditAccount extends Account {
    /**
     * -----------------------------------------------------------------------------------------------------
     * Constructs a new CreditAccount.
     * @param owner The owner of the checking account.
     * @param iban The international bank account number.
     */
    public CreditAccount(Person owner, String iban) {
        super(owner, iban, "CreditAccount",0, 0);
    }
}

