import java.util.ArrayList;
import java.util.HashMap;
import java.io.*;
import java.util.*;
import java.util.Random;
import java.util.Set;
/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is used to store the data of the users and their accounts. It is used to create, update and delete users
 * and accounts. It also has a method to save the data to a file and load it from a file.
 *
*/

public class DataBase {
    /**
     * -----------------------------------------------------------------------------------------------------
     * Attributes for the DataBase class.
     */
    private static ArrayList<Person> personList;
    private static HashMap<Person, ArrayList<Account>> AccList;
    public static ArrayList<Transaction> TransactionList;

    /**
     * -----------------------------------------------------------------------------------------------------
     * Constructs a new DataBase.
     */
    public DataBase() {
        personList = new ArrayList<>();
        AccList = new HashMap<>();
        TransactionList = new ArrayList<>();
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to get account by person.
     */
    public static Account getAcc(Person p, String accType){
        int i = -1;
        switch (accType){
            case "CheckingAccount":
                i = 0;
                break;
            case "CreditAccount":
                i = 1;
                break;
            case "SavingsAccount":
                i = 2;
                break;
        }
        return AccList.get(p).get(i);
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to create a person.
     * @param p The person to be added to the personList.
     */
    public static void createUser(Person p) {
        personList.add(p);
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to create an account for a person.
     */
    public static void createAcc(Person p, ArrayList<Account> accFromUser){
        AccList.put(p, accFromUser);
    }
    /**
     * -----------------------------------------------------------------------------------------------------
     * Getter und Setter methods for the DataBase class.
     */

    public static ArrayList<Transaction> getTransactionList() {
        return TransactionList;
    }

    public static void setTransactionList(ArrayList<Transaction> transactionList) {
        TransactionList = transactionList;
    }
    public static HashMap<Person, ArrayList<Account>> getAccList() {
        return AccList;
    }

    public static void setAccList(HashMap<Person, ArrayList<Account>> accList) {
        AccList = accList;
    }

    public static ArrayList<Person> getPersonList() {
        return personList;
    }

    public static void setPersonList(ArrayList<Person> personList) {
        DataBase.personList = personList;
    }

    public static Account getAccountByIban(String iban){

        for (Map.Entry<Person, ArrayList<Account>> entry : AccList.entrySet()) {
            ArrayList<Account> accounts = entry.getValue();
            for (Account account : accounts) {
                if (account == null){
                    continue;
                }
                if (account.getIban_().equals(iban)) {
                    return account;
                }
            }
        }
        return null;
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to generate a random IBAN.
     * @return A random IBAN.
     */
    public static String generateIban() {
        Set<String> existingIbans = extractIbans(getAccList());
        String iban;
        do {
            iban = "CB240000" + generateRandomNumber(8);
        } while (existingIbans.contains(iban));
        return iban;
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to generate a random BIC.
     * @return A random BIC.
     */
    private static Set<String> extractIbans(HashMap<Person, ArrayList<Account>> accDB) {
        Set<String> ibans = new HashSet<>();
        for (ArrayList<Account> accounts : accDB.values()) {
            for (Account account : accounts) {
                if (account == null)
                    continue;
                ibans.add(account.getIban_());
            }
        }
        return ibans;
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Method to generate a random number.
     * @return A random number as a String.
     */
    private static String generateRandomNumber(int length) {
        Random random = new Random();
        StringBuilder randomNumber = new StringBuilder();
        for (int i = 0; i < length; i++) {
            randomNumber.append(random.nextInt(10));
        }
        return randomNumber.toString();
    }




}
 /*
    // Method to save data to a file
    public void saveToFile() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("database.ser"))) {
            out.writeObject(persons);
            out.writeObject(accounts);
        } catch (IOException e) {
            System.err.println("ERROR: Unable to save data.");
        }
    }
    // Method to load data from a file
    @SuppressWarnings("unchecked")
    private void loadFromFile() {
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream("database.ser"))) {
            persons = (Map<String, Person>) in.readObject();
            accounts = (Map<String, Account>) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("ERROR: Unable to load data. Starting with an empty database.");
        }
    }

    // Add methods to interact with the persons and accounts maps
    public void addPerson(String key, Person person) {
        persons.put(key, person);
        saveToFile();
    }

    public void addAccount(String key, Account account) {
        accounts.put(key, account);
        saveToFile();
    }

    public void removeAccount(String key) {
        if (accounts.containsKey(key)) {
            accounts.remove(key);
            saveToFile(); // Save changes
        }
    }

    public Person getPerson(String key) {
        return persons.get(key);
    }

    public Account getAccount(String key) {
        return accounts.get(key);
    }

    public void updatePerson(String key, Person updatedPerson) {
        if (persons.containsKey(key)) {
            persons.put(key, updatedPerson);
            saveToFile(); // Save changes
        }
    }

    public void updateAccount(String key, Account updatedAccount) {
        if (accounts.containsKey(key)) {
            accounts.put(key, updatedAccount);
            saveToFile(); // Save changes
        }
    }
    }*/

