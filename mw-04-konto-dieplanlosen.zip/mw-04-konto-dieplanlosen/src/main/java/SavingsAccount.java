/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the savings account object.
 */
public class SavingsAccount extends Account {
    /**------------------------------------------------------------------------------------------------------
     * Constructs a new SavingsAccount.
     * @param owner The owner of the savings account.
     * @param iban The international bank account number.
     */
    public SavingsAccount(Person owner, String iban) {
        super(owner, iban, "SavingsAccount",0, 0);
    }
}