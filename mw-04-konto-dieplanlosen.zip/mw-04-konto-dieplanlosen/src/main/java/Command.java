import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Scanner;

/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the command object.
 */
public class Command {

    /**
     * ------------------------------------------------------------------------------------------------------
     * Attributes for the Command class.
     */
    public static boolean userIsLoggedIn = false;
    public static Person pLoggedIn = null;
    public static String commandType;
    public static String[] parameters;
    public static String accLoggedInIban;
    public static Account accLoggedIn = null;
    private Scanner scanner = new Scanner(System.in);

    /**
     * ------------------------------------------------------------------------------------------------------
     * Constructor for the Command class.
     *
     * @param command    The command.
     * @param parameters The parameters.
     */
    public Command(String command, String[] parameters) {
        this.commandType = command;
        this.parameters = parameters;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * Executes the specified command.
     *
     * @param command The command object containing the command type and parameters.
     * @param db      The database containing account and transaction data.
     * @return Returns -1 if the command is "exit", 0 if the command is executed successfully.
     */
    public int executeCommand(Command command, DataBase db) {

        switch (commandType) {
            case "exit":
                if (parameters.length == 0) {
                    return -1;
                } else {
                    System.out.println("ERROR: Invalid number of parameters!");
                }
                break;
            case "login":
                handleLogin(db);
                break;

                case "logout":
                    handleLogout();
                    break;

                case "deposit":
                    handleDeposit(db);
                    break;

                case "withdraw":
                    handleWithdraw(db);
                    break;

                case "balance":
                    handleBalance(db);
                    break;

                case "statement":
                    handleStatement();
                    break;

                case "transfer":
                    handleTransfer(db);
                    break;

                case "help":
                    handleHelp();
                    break;

                case "open":
                    open(db);
                    break;

                case "close":
                    close(db);
                    break;

                default:
                    System.out.println("ERROR: Unknown command!");
                    break;
            }
        return 0;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method closes the specified account.
     *
     * @param db The database.
     */
    private void close(DataBase db) {
        if (parameters.length != 1) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return;
        }
        Account delAcc = db.getAccountByIban(parameters[0]);
        if (delAcc == null) {
            System.out.println("ERROR: The Account not exist!");
            return;
        }

        String accType = delAcc.getType_();

        int index = getIndexFromAccType(accType);
        if (db.getAccList().get(pLoggedIn).get(index).getBalance_() == 0){
            db.getAccList().get(pLoggedIn).set(index, null);
            System.out.println("INFO: Account " + parameters[0] + " closed.");
        }else{
            System.out.println("Error : der acc muss leer sein");// TODO : Marco
            return;
        }
// login Amalia Glenn CB23000022219067

        ArrayList<Account> allUserAcc = db.getAccList().get(pLoggedIn);
        int count = 0;

        for (Account a : allUserAcc) {
            if (a == null) {
                count++;
            }
        }
        if (count == 3) {
            db.getAccList().remove(pLoggedIn);
            db.getPersonList().remove(pLoggedIn);
        }
        userIsLoggedIn = false;
        System.out.println("INFO: Logged out.");
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method opens a new account of the specified type with the specified maximum debt amount.
     *
     * @param db The database.
     */

    private void open(DataBase db) {
        String accType = "";
        double overdraftLimit;
        if (!userIsLoggedIn) {
            // Handle new user account opening
            if (parameters.length != 4) {
                System.out.println("ERROR: Invalid number of parameters!");
                return;
            }
            String fname = parameters[0];
            String lname = parameters[1];

            if (!checkUsername(fname) || !checkUsername(lname)) {
                System.out.println("ERROR: Invalid name! Please check the constrains for entering names.");
                return;
            }
            accType = parameters[2];
            overdraftLimit = stringToIntOpen(parameters[3]);

            if (overdraftLimit == -1)
                return;

            if (!errorHandlingNewUser(accType, overdraftLimit))
                return;

            createNewUser(db, fname, lname, accType, overdraftLimit);

        } else {
            if (parameters.length != 2) {
                System.out.println("ERROR: Invalid number of parameters!");
                return;
            }
            // Handle existing user account opening
            accType = parameters[0];
            overdraftLimit = stringToIntOpen(parameters[1]);
            if (!errorHandlingNewUser(accType, overdraftLimit)) {
                return;
            }
            if (db.getAcc(pLoggedIn, accType) != null) {
                System.out.println("ERROR: You already have an account of this type!");
                return;
            }
            int index = getIndexFromAccType(accType);
            db.getAccList().get(pLoggedIn).set(index, newAcc(accType, overdraftLimit, db));
        }
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method checks if the username is valid.
     * @param name The name to be checked.
     * @return True if the name is valid, false otherwise.
     */
    public boolean checkUsername(String name) {
        for (char ch : name.toCharArray()) {
            if (!Character.isLetter(ch) && !Character.isWhitespace(ch)) {
                return false;
            }
        }
        return true;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method converts a string to an integer.
     * @param input The input as a string.
     * @return The input as an integer.
     */
    public int stringToIntOpen(String input) {
        int limit;
        try {
            limit = Integer.parseInt(input);
            if (limit < 0) {
                System.out.println("ERROR: Invalid allowance! Please enter a positive integer for the allowance.");
                return -1;
            }
        } catch (NumberFormatException e) {
            System.out.println("ERROR: Invalid allowance! Please enter a positive integer for the allowance.");
            return -1;
        }
        return limit;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method returns the index of the account type.
     * @param accType The account type.
     *                Rules:
     *                The account type must be "CheckingAccount", "CreditAccount", or "SavingsAccount".
     * @return The index of the account type.
     * The index is 0 for "CheckingAccount", 1 for "CreditAccount", and 2 for "SavingsAccount".
     * If the account type is invalid, the method returns -1.
     */
    public int getIndexFromAccType(String accType) {
        int index = -1;
        if (accType.equals("CheckingAccount")) {
            index = 0;
        }
        if (accType.equals("CreditAccount")) {
            index = 1;
        }
        if (accType.equals("SavingsAccount")) {
            index = 2;
        }
        return index;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method creates a new user.
     * @param db The database.
     *           Rules:
     *           The database must not be null.
     *           The first name must not be null.
     *           The last name must not be null.
     *           The account type must be "CheckingAccount", "CreditAccount", or "SavingsAccount".
     *           The overdraft limit must be a positive number.
     *           The birth date must not be null.
     *           The birth date must be in the format "DD.MM.YYYY".
     *           The birth date must be a logical date (i.e. not in the future).
     *           The user must be 18 years or older.
     *           The user must not be logged in.
     *           The user must not already exist in the database.
     *           The user must not already have an account of the specified type.
     */

    private void createNewUser(DataBase db, String fname, String lname, String accType,
                               double overdraftLimit) {

        String bDay = "";
        System.out.println(bDay);
         boolean isValidDate = false;

        while (!isValidDate) {
            System.out.print("Enter your birth date (DD.MM.YYYY): ");
            bDay = scanner.nextLine();
            isValidDate = CommandLine.getBirthDay(bDay);

        }
        // Rest of the user creation logic...
        Person p = new Person(fname, lname, bDay);
        db.getPersonList().add(p);
        ArrayList<Account> newPersonAccList = new ArrayList<>();
        if (accType.equals("CheckingAccount")) {
            newPersonAccList.add(newAcc(accType, overdraftLimit, db));
        } else {
            newPersonAccList.add(null);
        }
        if (accType.equals("CreditAccount")) {
            newPersonAccList.add(newAcc(accType, overdraftLimit, db));
        } else {
            newPersonAccList.add(null);
        }
        if (accType.equals("SavingsAccount")) {
            newPersonAccList.add(newAcc(accType, overdraftLimit, db));
        } else {
            newPersonAccList.add(null);
        }
        db.getAccList().put(p, newPersonAccList);
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method creates a new account.
     * @param accType The account type.
     *                Rules:
     *                The account type must be "CheckingAccount", "CreditAccount", or "SavingsAccount".
     *                Generating an iban and bic for the new account.
     */
    private Account newAcc(String accType, double overdraftLimit, DataBase db) {

        String iban = db.generateIban();

        Account newAcc = null;

        switch (accType){
            case "CheckingAccount":
                newAcc = new CheckingAccount(pLoggedIn, iban, overdraftLimit);
                break;
            case "CreditAccount":
                newAcc = new CreditAccount(pLoggedIn, iban);
                break;
            case "SavingsAccount":
                newAcc = new SavingsAccount(pLoggedIn, iban);
                break;
        }
        System.out.println("INFO: Your IBAN is " + iban + " and your BIC is " + newAcc.getBic_() + ".");
        return newAcc;
    }


    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the error of a new user.
     * @return True if the error is handled, false otherwise.
     * @param accType The account type.
     *                Rules:
     *                The account type must be "CheckingAccount", "CreditAccount", or "SavingsAccount".
     *                Checking accounts and credit accounts must have an allowance of 0.
     *                Savings accounts do not have an allowance.
     *                The allowance must be a positive number.
     *                The user must not be logged in.
     *                The user must not already exist in the database.
     *                The user must not already have an account of the specified type.
     */
    private boolean errorHandlingNewUser(String accType, double overdraftLimit) {
        if (accType.equals("CheckingAccount") || accType.equals("CreditAccount") ||
                accType.equals("SavingsAccount")) {
            if (accType.equals("CreditAccount") && overdraftLimit == 0 ||
                    accType.equals("SavingsAccount") && overdraftLimit == 0 || accType.equals("CheckingAccount")) {
                return true;
            } else {
                System.out.println("ERROR: Invalid allowance! Savings accounts do not have an allowance. " +
                        "Please enter 0 for this value.");
                return false;
            }
        } else {
            System.out.println("ERROR: Invalid account type!");
            return false;
        }

    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the login.
     * Logs in to the system with the specified username and IBAN.
     */
    private static void handleLogin(DataBase db) {
        if (Command.parameters.length != 3) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (userIsLoggedIn) {
            System.out.println("ERROR: You are already logged in!");
            return;
        }

        String firstName = Command.parameters[0];
        String lastName = Command.parameters[1];
        String iban = Command.parameters[2];

        ArrayList<Account> allAccFromUser = null;
        HashMap<Person, ArrayList<Account>> accDB = db.getAccList();

        for (Person p : db.getPersonList()) {
            if (p.getFirstName().equals(firstName) &&
                    p.getLastName().equals(lastName)) {
                pLoggedIn = p;

                allAccFromUser = accDB.get(pLoggedIn);
                break;
            }
        }
        // --------------------------------------------------------------------------------------------------------------
        if (pLoggedIn == null) {
            System.out.println("ERROR: Invalid username!");
            return;
        }
        // --------------------------------------------------------------------------------------------------------------
        String ibanDB;
        accLoggedInIban = null;
        Account check = null;
        Account credit = null;
        Account saving = null;
        if (allAccFromUser != null) {
            check = allAccFromUser.get(0);
            credit = allAccFromUser.get(1);
            saving = allAccFromUser.get(2);
        }
        String accountType = "";
        if (check != null) {
            ibanDB = check.getIban_();
            if (ibanDB.equals(iban)) {
                accLoggedIn = allAccFromUser.get(0);
                accLoggedInIban = iban;
                accountType = "CheckingAccount";
            }
        }

        if (credit != null) {
            ibanDB = credit.getIban_();
            if (ibanDB.equals(iban)) {
                accLoggedIn = allAccFromUser.get(1);
                accLoggedInIban = iban;
                accountType = "CreditAccount";
            }
        }
        if (saving != null) {
            ibanDB = saving.getIban_();
            if (ibanDB.equals(iban)) {
                accLoggedIn = allAccFromUser.get(2);
                accLoggedInIban = iban;
                accountType = "SavingsAccount";
            }
        }
        if (pLoggedIn != null && accLoggedInIban != null) {
            userIsLoggedIn = true;
            System.out.println(
                    "INFO: Successfully logged into the " + accountType + " of "
                            + firstName + " " + lastName + ".");
            System.out.println("---");
            System.out.println("Welcome " + firstName + " " + lastName +
                    ".\n---");
        } else {
            // ----------------------------------------------------------------------------------------------------------
            if (accLoggedInIban == null) {
                System.out.println("ERROR: Invalid IBAN!");
            }
            // ----------------------------------------------------------------------------------------------------------
        }
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the logout.
     * Logs the current account out of the system.
     */
    private static void handleLogout() {
        if (Command.parameters.length > 0) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return;
        }
        userIsLoggedIn = false;
    }

    /**
     *  ------------------------------------------------------------------------------------------------------
     * This method handles the deposit.
     * Deposits the specified amount to the account.
     */
    private static void handleDeposit(DataBase db) {
        if (errorHandleDepWit())
            return;
        double amount = stringToDouble(parameters[0]);

        // -----------------------------------------------------------------------------------------------------------------------------------
        Transaction deposit = new Transaction("----------------", accLoggedInIban, amount, "DEPOSIT");
        // db.getTransactionList().add(deposit);
        // -----------------------------------------------------------------------------------------------------------------------------------
        accLoggedIn.setBalance_(amount);
        accLoggedIn.addTransaction(deposit);
        /*
         * ArrayList <Account> alluseracc = db.getAccList().get(pLoggedIn);
         * for (Account a : alluseracc){
         * if (a.equals(accLoggetIn)){
         * a.addTranaction(deposit);
         * break;
         * }
         * }
         */
        System.out.println("INFO: Successfully deposited " + amount + " to your account.");
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the withdrawal.
     * Withdraws the specified amount from the account.
     */
    private static void handleWithdraw(DataBase db) {
        if (errorHandleDepWit())
            return;
        double amount = stringToDouble(parameters[0]);
        Transaction withdraw = new Transaction(accLoggedInIban, "----------------", -amount, "CASH WITHDRAWAL");
        // db.getTransactionList().add(deposit);
        if (accLoggedIn.getBalance_() -amount < accLoggedIn.getOverdraft_limit_()*(-1)){
            System.out.println("Error: You do not have enough funds to withdraw " + amount + " €!");
            return;
        }
        accLoggedIn.setBalance_(-amount);
        accLoggedIn.addTransaction(withdraw);
        System.out.println("INFO: Successfully withdrawn " + amount + " from your account.");
    }
// login Amalia Glenn CB23000022219067
    /**
     *  ------------------------------------------------------------------------------------------------------
     * This method handles the balance.
     */
    private static void handleBalance(DataBase db) {
        if (Command.parameters.length > 0) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return;
        }
        double b = accLoggedIn.getBalance_();
        double balance = 0;


         /*  for (Transaction tran : accLoggedIn.getTransactions_()) {
            balance += tran.getAmount();
        }


         * for (Transaction bal : db.getTransactionList()) {
         * if (!bal.getIncomingIban().equals(accLoggedInIban) &&
         * !bal.getOutgoingIban().equals(accLoggedInIban)) {
         * continue;
         * }
         * if (bal.getIncomingIban().equals(accLoggedInIban)){
         * balance += bal.getAmount();
         * }
         * if (bal.getOutgoingIban().equals(accLoggedInIban)){
         * balance -= bal.getAmount();
         * }
         * }
         */
        System.out.println("INFO: Your balance is: " + String.format(Locale.US, "%.2f", b) + " €");
    }

    // login Cian Grimes CB23000062347302
    // login Amalia Glenn CB23000022219067

    /**
     *  ------------------------------------------------------------------------------------------------------
     * Prints the bank statement containing all transactions of the logged in account.
     * Prints the bank statement containing all transactions of the logged in
     * account.
     * <p>
     * Command: statement
     * Parameters: None
     * Rules:
     * <p>
     * The format of a bank statement is best described with an example:
     * <p>
     * INFO: Printing bank statement for account: CB23000022219067
     * <p>
     * Outgoing IBAN | Ingoing IBAN | Transaction Type | Amount
     * -----------------+------------------+-------------------+-------
     * ---------------- | CB23000022219067 | DEPOSIT | 100.00 €
     * ---------------- | CB23000022219067 | DEPOSIT | 50.00 €
     * CB23000022219067 | ---------------- | CASH WITHDRAWAL | -40.00 €
     * CB23000022219067 | CB23000095654823 | BANK TRANSFER | -60.00 €
     * A bank statement should contain the following information:
     * <p>
     * The outgoing IBAN is the IBAN of the account that the money was
     * transferred/withdrawn from.
     * The ingoing IBAN is the IBAN of the account that the money was
     * transferred/deposited to.
     * The transaction type is the type of the transaction. Possible types are:
     * DEPOSIT: The money was deposited to the account.
     * CASH WITHDRAWAL: The money was withdrawn from the account.
     * BANK TRANSFER: The money was transferred from the account to another account.
     * The amount is the amount of money that was transferred/deposited/withdrawn.
     * The amount should be displayed with 2 decimal places.
     * The amount should be displayed with the currency symbol (€).
     * The amount should be displayed with a minus sign (-) if the transaction was a
     * withdrawal or a bank transfer.
     * Formatting tips: instead of copying the number of "-" characters try to
     * calculate the number of needed
     * whitespaces when printing something. Look at the number of characters needed
     * for the longest string found in a column above.
     * This should give you an idea to ensure your code still works, if for example
     * a new transaction type is implemented. (Code Durability).
     * <p>
     * Hint: You should use the Transaction class to store the information of a
     * transaction.
     * <p>
     * Everytime a transaction is made (deposit, withdrawal, bank transfer), you can
     * create a new Transaction object and add it to a list of transactions.
     */
    private static void handleStatement() {
        if (Command.parameters.length > 0) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return;
        }
        // --------------------------------------------------------------------------------------------------------------
        if (accLoggedIn.getTransactions_().isEmpty()) {
            System.out.println("ERROR: No transactions to show!");
            return;
        }
        // --------------------------------------------------------------------------------------------------------------
        System.out.println("Outgoing IBAN    | Ingoing IBAN     | Transaction Type  | Amount");
        System.out.println("-----------------+------------------+-------------------+-------");

        for (Transaction trans : accLoggedIn.getTransactions_()) {
            System.out.println(trans.getOutgoingIban() + " | " + trans.getIncomingIban() + " | " +
                    trans.getTransactionType() + getDistance(trans.getTransactionType()) + " | " +
                    String.format(Locale.US, "%.2f", trans.getAmount()) + " €");
        }
    }
/**
 * ------------------------------------------------------------------------------------------------------
 * This method returns the distance between the transaction type and the amount.
 */
    public static String getDistance(String txt) {
        int emptyCount = 17 - txt.length();
        StringBuilder empty = new StringBuilder();
        for (int i = 0; i < emptyCount; i++) {
            empty.append(" ");
        }
        return empty.toString();
    }



    // login Amalia Glenn CB23000022219067
    // login Cian Grimes CB23000062347302

    /**
     *  ------------------------------------------------------------------------------------------------------
     * Transfers the specified amount from your account to the specified IBAN.
     */
    private static void handleTransfer(DataBase db) {
        if (Command.parameters.length != 2) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return;
        }
        double amount = stringToDouble(parameters[0]);
        if (amount <= 0) {
            return;
        }
        if (amount == -1)
            return;
        if (accLoggedIn.getBalance_()-amount < accLoggedIn.getOverdraft_limit_()*(-1)){
            System.out.println("Error: You do not have enough funds to withdraw " + amount + " €!");
            return;
        }
        // --------------------------------------------------------------------------------------------------------------
        String receivingIban = Command.parameters[1];
        if (receivingIban.equals(accLoggedInIban)) {
            System.out.println("ERROR: Cannot transfer to the same account!");
            return;
        }

        Account receivingAccount = db.getAccountByIban(receivingIban);
        if (receivingAccount == null) {
            System.out.println("ERROR: Invalid IBAN!");
            return;
        }

        Transaction withdrawal = new Transaction(accLoggedInIban, receivingIban, -amount, "BANK TRANSFER");
        Transaction deposit = new Transaction(accLoggedInIban, receivingIban, amount, "BANK TRANSFER");

        accLoggedIn.addTransaction(withdrawal);
        accLoggedIn.setBalance_(-amount);
        receivingAccount.addTransaction(deposit);
        receivingAccount.setBalance_(amount);

        System.out.println(
                "INFO: " + String.format(Locale.US, "%.2f", amount) + " € transferred to " + receivingIban + ".");

        }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the help command.
     * It prints the available commands and their descriptions.
     */
    private static void handleHelp() {
        if (Command.parameters.length > 0) {
            System.out.println("ERROR: Invalid number of parameters!");
            return;
        }
        System.out.println("Available commands:\n" +
                "--------------------------------------------------------------------------------\n" +
                "login <firstname> <lastname> <IBAN>\n" +
                "\t - Logs in to the system with the specified username and IBAN.\n" +
                "\t - The username consists of a first name and a last name, separated by a space.\n" +
                "\t \n" +
                "deposit <amount>\n" +
                "\t - Deposits the specified amount to the account.\n" +
                "\t   The amount must be a positive number.\n" +
                "\t   \n" +
                "withdraw <amount>\n" +
                "\t - Withdraws the specified amount from the account.\n" +
                "\t   The amount must be a positive number.\n" +
                "\t   \n" +
                "statement\n" +
                "\t - Prints the bank statement of the specified account.\n" +
                "\t \n" +
                "balance\n" +
                "\t - Prints the current balance of the specified account.\n" +
                "\t \n" +
                "logout\n" +
                "\t - Logs the current account out of the system.\n" +
                "\t \n" +
                "transfer <amount> <iban>\n" +
                "\t - Transfers the specified amount from your account to the specified IBAN.\n" +
                "\t \n" +
                "open <Firstname> <Lastname> <account_type> <maximum_debt_amount>\n" +
                "\t - Opens a new account of the specified type with the specified maximum debt amount.\n" +
                "\t   Account types: \"CheckingAccount\", \"CreditAccount\", \"SavingsAccount\"\n" +
                "\t   For SavingsAccount enter 0 for <maximum_debt_amount>.\n" +
                "\t WARNING: If user is already logged in use:\n" +
                "\t\topen <account_type> <maximum_debt_amount>\n" +
                "\t\t\n" +
                "close <iban>\n" +
                "\t - Closes the specified account.\n" +
                "\t \n" +
                "exit\n" +
                "\t - Exits the program.\n" +
                "\t \n" +
                "help\n" +
                "\t - Prints this help message.\n" +
                "--------------------------------------------------------------------------------");
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method handles the error of a deposit or withdrawal.
     * @return True if the error is handled, false otherwise.
     *              Rules:
     *               The amount must be a positive number.
     *               The user must be logged in.
     *               The amount must be a positive number.
     *               The user must have enough money in their account to withdraw the specified amount.
     *               The user must have enough money in their account to transfer the specified amount or have enough
     *               allowance to afford a transfer of given amount.
     *               The IBAN must be valid (i.e. the account must exist).
     *               The IBAN must not be the same as the IBAN of the account that the money is transferred from.
     *               A successfull bank transfer should print the following output:
     *               INFO: <amount> € transferred to <Receiving_IBAN>.
     */


    private static boolean errorHandleDepWit() {
        if (Command.parameters.length != 1) {
            System.out.println("ERROR: Invalid number of parameters!");
            return true;
        }
        if (!userIsLoggedIn) {
            System.out.println("ERROR: You must be logged in to execute this command!");
            return true;
        }
        double amount = stringToDouble(parameters[0]);
        if (amount <= 0) {
            return true;
        }
        return false;
    }
    private static double stringToDouble(String amountS ) {
        double amount = 0;
            String[] amount_String_Double = amountS.split("\\.");
            try {
                if (amount_String_Double[1].length() > 2 ){
                    System.out.println("Error: Only two decimal places possible!");
                    return -1;
                }
            }catch (ArrayIndexOutOfBoundsException ignored){
                //wenn keine nachkommerstelle da ist
            }

        try {
            amount = Double.parseDouble(amountS);
            if (amount <= 0) {
                System.out.println("ERROR: Amount must be a positive number!");
                return -1;
            }
        } catch (NumberFormatException e) {
            System.out.println("ERROR: Invalid parameter type!");
            amount = -1;
        }
        return amount;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * This method converts a string to an integer.
     * @param amountS The amount as a string.
     * @return The amount as an integer.
     */
    private static int stringToInt(String amountS) {
        int amount;
        try {
            amount = Integer.parseInt(amountS);
            if (amount < 0) {
                System.out.println("ERROR: Amount must be a positive number!");
                return 0;
            }
        } catch (NumberFormatException e) {
            System.out.println("ERROR: Invalid parameter type!");
            return 0;
        }
        return amount;
    }
}

