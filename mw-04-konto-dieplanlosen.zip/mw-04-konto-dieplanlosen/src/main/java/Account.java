import java.util.ArrayList;

/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for creating the account object, which is used to represent a bank account.
 */
public class Account {
    /**------------------------------------------------------------------------------------------------------
     * Attributes for the Account class.
     */
    private Person owner_;
    private  String iban_;
    private String bic_;
    private String type_;
    private  double balance_;
    private double overdraft_limit_;
    private ArrayList<Transaction> transactions_;

    /**
     * -----------------------------------------------------------------------------------------------------
     * Constructs a new Account.
     * @param owner The owner of the account, represented by a Person object.
     * @param iban The international bank account number.
     * @param type The type of account (e.g., savings, checking).
     * @param overdraftLimit The overdraft limit for the account.
     */
    public Account(Person owner, String iban, String type, double balance, double overdraftLimit) {
        this.owner_ = owner;
        this.iban_ = iban;
        this.bic_ = "CPKAPF24";
        this.type_ = type;
        this.balance_ = balance;
        this.overdraft_limit_ = overdraftLimit;
        this.transactions_ = new ArrayList<>();
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Adds a transaction to the account.
     * @param transaction The transaction to be added to the account.
     */
    public void addTransaction(Transaction transaction ){
        transactions_.add(transaction);
    }

    /**
     * -----------------------------------------------------------------------------------------------------
     * Getter and setter methods for the Account class.
     */
    public Person getOwner_() {
        return owner_;
    }

    public void setOwner_(Person owner_) {
        this.owner_ = owner_;
    }

    public  String getIban_() {
        return iban_;
    }

    public void setIban_(String iban_) {
        this.iban_ = iban_;
    }

    public String getBic_() {
        return bic_;
    }

    public void setBic_(String bic_) {
        this.bic_ = bic_;
    }

    public String getType_() {
        return type_;
    }

    public void setType_(String type_) {
        this.type_ = type_;
    }

    public double getBalance_() {
        return balance_;
    }

    public void setBalance_(double amount) {
        this.balance_ = getBalance_() + amount;
    }

    public double getOverdraft_limit_() {
        return overdraft_limit_;
    }

    public void setOverdraft_limit_(double overdraft_limit_) {
        this.overdraft_limit_ = overdraft_limit_;
    }

    public ArrayList<Transaction> getTransactions_() {
        return transactions_;
    }

    public void setTransactions_(ArrayList<Transaction> transactions_) {
        this.transactions_ = transactions_;
    }
}