import java.io.FileNotFoundException;
/**
 * Authors: Marco Baumgartner, Marcel Müllner, Santa Claus
 * Date: 12.02.2024
 * Version: 1.0
 * This program serves as a banking application that manages user accounts and transactions. It is capable of reading
 * user and account data from a specified configuration file, processing banking commands, and executing transactions.
 * The program supports different types of accounts including Checking, Savings, and Credit accounts, each with unique
 * behaviors and constraints. Users can perform various operations such as depositing, withdrawing,
 * and transferring funds between accounts, with the system enforcing rules such as
 * overdraft limits and transaction validation.
 */

public class Main {
    /**------------------------------------------------------------------------------------------------------
     * Main method for the program.
     * @param args The arguments for the program.
     */

    /*
    TODO : abgleich mit Bsp ausgabe
     */
    public static void main(String[] args) {
        // Defining the filename
        // ******************************************************
        // Choose one of the following:
        //String filename = CommandLine.getFileName();
        // String filename = "files/config_01.txt";
        // String filename = "files/config_02.txt";
        // String filename = "files/bad_config.txt";
        // ******************************************************
        // Creating the database
        DataBase db = new DataBase();
        // Creating a command
        Command command = null;
        // Reading the file, the constructor has already been filled correctly
        try {
            ReadFiles rf = new ReadFiles(CommandLine.getFileName());
            if (!rf.read(db)) {
                System.exit(1);
            }
        } catch (FileNotFoundException fnfe) {
            System.out.println("ERROR: File not found!");
            System.exit(1);
        }
        // Reading the commands and executing them
        while (true) {
            command = CommandLine.readCommand();
            if (command.executeCommand(command,db) == -1) {
                // Exiting the program if the function "executeCommand" returns -1
                System.out.println("INFO: Exiting program...");
                System.exit(0);
            }
        }
    }
}
