import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/**
 * Authors: Marco Baumann, Marcel Müllner, Claus Hierzer
 * Date: 12.02.2024
 * Version: 1.0
 * This class is responsible for reading the file and creating the database
 * with the information from the file.
 */
public class ReadFiles {
    /**------------------------------------------------------------------------------------------------------
     * Attributes for the ReadFiles class.
     */
    private File file_;
    private Scanner fileReader_;

    /**
     * ------------------------------------------------------------------------------------------------------
     * Constructor for the ReadFiles class.
     * @param filename The name of the file to be read.
     * @throws FileNotFoundException If the file is not found.
     */
    public ReadFiles(String filename) throws FileNotFoundException {
        file_ = new File(filename);
        fileReader_ = new Scanner(file_);
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * Reads the file and creates the database with the information from the file.
     * @param db The database to be created.
     * @return True if the file was read successfully, false otherwise.
     */
    public boolean read(DataBase db) {

        String firstLine = fileReader_.nextLine();
        if (!firstLine.equals("CODERSBAY")) {
            System.out.println("ERROR: Incorrect file format!");
            return false;
        }
        fileReader_.nextLine();
        ReadData(db);

        return true;
    }

    /**
     * ------------------------------------------------------------------------------------------------------
     * Reads the data from the file and creates the database with the information from the file.
     * @param db The database to be created.
     */
    public void ReadData(DataBase db) {
        while (fileReader_.hasNextLine()) {
            String dataLine = fileReader_.nextLine();
            String[] data = dataLine.split(", ");
            String[] name = data[0].split(" ");

            Person newPerson = new Person(name[0], name[1], data[1]);
            db.createUser(newPerson);

            CheckingAccount checking = null;
            if (!data[2].equals("X")) {
                checking = new CheckingAccount(newPerson, data[2], 0);

            }
            CreditAccount credit = null;
            if (!data[3].equals("X")) {
                credit = new CreditAccount(newPerson, data[3]);
            }
            SavingsAccount saving = null;
            if (!data[4].equals("X")) {
                saving = new SavingsAccount(newPerson, data[4]);
            }

            ArrayList<Account> accountArrayList = new ArrayList<>();
            accountArrayList.add(checking);
            accountArrayList.add(credit);
            accountArrayList.add(saving);

            db.createAcc(newPerson,accountArrayList);
        }


        fileReader_.close();
    }
}