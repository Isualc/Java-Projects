# Milestone 2

After the basic program structure was implemented in Milestone 1, this milestone deals
with adding new users and accounts to the database, aswell as saving the database to a file.


1. File reading (see [Milestone 1](Milestone_1.md#file-reading))
2. The main functionality (see [Milestone 1](Milestone_1.md#commands))
3. Advanced functionality, which consists of adding new people and account into the system should also be implemented
  - [Open](#open)
  - [Close](#close)
4. [ERROR HANDLING](#error-messages)
5. BONUS: [Saving the data](#file-writing)

---
## Advanced Functionality
### Open
Opens a new account of the specified type with the specified maximum debt amount.
#### New User
- **Command:** `open <firstname> <lastname> <account_type> <maximum_debt_amount>`
- **Parameters:**
  - `<firstname>`: The first name of the user.
  - `<lastname>`: The last name of the user.
  - `<account_type>`: The type of the account that should be opened.
  - `<maximum_debt_amount>`: The maximum debt amount of the account that should be opened.
- **Rules:**
  - The user must not be logged in.
  - The account type must be valid (i.e. the account type must exist).
  - The maximum debt amount must be a positive number.
  - The maximum debt amount must be 0 if the account type is SavingsAccount.

#### Existing User
- **Command:** `open <account_type> <maximum_debt_amount>`
- **Parameters:**
  - `<account_type>`: The type of the account that should be opened.
  - `<maximum_debt_amount>`: The maximum debt amount of the account that should be opened.
- **Rules:**
  - The user must be logged in.
  - The account type must be valid (i.e. the account type must exist).
  - The maximum debt amount must be a positive number.
  - The maximum debt amount must be 0 if the account type is SavingsAccount.


A successfull account opening for should print the following output:
```
INFO: Your IBAN is <generated_iban> and your BIC is <bic>.
```
> Note that ```<generated_iban>``` and ```<bic>``` should be replaced with the corresponding values.
> <bic> is **always** the standard value of CPKAPFXX
> (where XX is replaced with the current year you are doing this assignment in).
>
> This output applies to both new and existing users.

---
### Close
Closes the specified account **and** logs out the user.
- **Command:** `close <iban>`
- **Parameters:**
  - `<iban>`: The IBAN of the account that should be closed.
- **Rules:**
  - The user must be logged in.
  - The IBAN must be valid (i.e. the account must exist).
  - The IBAN must be the same as one of the accounts of the user.
  - The account must not have any money in it.

A successfull account closing should print the following output:
```
INFO: Account <iban> closed.
INFO: Logged out.
```
> Note that ```<iban>``` should be replaced with the corresponding value.
---

## Error Messages
If an incorrect command or a command which violates the program logica is entered, the corresponding error message is printed.
Afterwards, the input prompt is shown again and the user can enter a new command.

There can be a maximum of one (1) error message per command entered. If several errors occur, the error with the highest priority is printed.
The earlier the command is listed in the table below, the higher the priority of the error message.

|                             Command                              |                                            Error Type                                             |                                             Error Message                                             |
|:----------------------------------------------------------------:|:-------------------------------------------------------------------------------------------------:|:-----------------------------------------------------------------------------------------------------:|
|                                ?                                 |                                  An unknown command was entered                                   |                                       `ERROR: Unknown command!`                                       |
|                               all                                |                 An incorrect number of parameters was used for the given command.                 |                                `ERROR: Invalid number of parameters!`                                 |
| deposit, withdraw, balance, statement, transfer, logout,  close  |                The account is not logged in therefore can not execute the command.                |                        `ERROR: You must be logged in to execute this command!`                        |
|                              login                               |                                   A user is already logged in.                                    |                                  `ERROR: You are already logged in!`                                  |
|                              login                               |     The specified username was not found in the dataset (includes not being typed correctly)      |                                      `ERROR: Invalid username!`                                       |
|                              login                               |            The given IBAN can not be associated with any of the IBANs in the dataset.             |                                        `ERROR: Invalid IBAN!`                                         |
|                        deposit, withdraw                         |                            The amount entered was not of correct type.                            |                                   `ERROR: Invalid parameter type!`                                    |
|                        deposit, withdraw                         |                                   The amount is 0 or negative.                                    |                              `ERROR: Amount must be a positive number!`                               |
|                             withdraw                             | The amount is greater than the available funds  (including the allowance for Checking and Credit) |                     `Error: You do not have enough funds to withdraw <amount> €!`                     |
|                            statement                             |                        The account does not have any transaction to show.                         |                                   `ERROR: No transactions to show!`                                   |
|                        transfer                         |                            The amount entered was not of correct type.                            |                                   `ERROR: Invalid parameter type!`                                    |
|                        transfer                         |                                   The amount is 0 or negative.                                    |                              `ERROR: Amount must be a positive number!`                               |
|                             transfer                             |               The account does not have enough funds to transfer the given amount.                |                                     `ERROR: Insufficient funds!`                                      |
|                             transfer                             |              The given IBAN can not be associated with any of the IBANs in the dataset.              |                                        `ERROR: Invalid IBAN!`                                         |
|                               open                               |                     The name entered contains numbers or special characters.                      |                `ERROR: Invalid name! Please check the constrains for entering names.`                 |
|                               open                               |                     The date of birth is not formatted correctly (DD.MM.YYYY)                     |                 `ERROR: Invalid date of birth! Use the following format (DD.MM.YYY).`                 |
|                               open                               |                         The date of birth can not be parsed to integers.                          |       `ERROR: Invalid date of birth! Please only enter valid integers, seperated by dots (.) .`       |
|                               open                               | The date of birth is outside of the basic calendar rules (31.02.2000 does not exist for example)  |                    `ERROR: Invalid date of birth! The given date does not exist!`                     |
|                               open                               |                The date of birth entered translates to an age lower than 18 years.                |           `ERROR: Invalid date of birth! You must be 18 years or older to open an account.`           |
|                               open                               |                                   The account type is invalid.                                    |                                    `ERROR: Invalid account type!`                                     |
|                               open                               |                        The user already has an account of the given type.                         |                          `ERROR: You already have an account of this type!`                           |
|                               open                               |               The type is SavingsAccount AND the allowance entered is not zero (0)                | `ERROR: Invalid allowance! Savings accounts do not have an allowance. Please enter 0 for this value.` |
|                               open                               |          The type is valid BUT the allowance entered is negative or not of type integer.          |            `ERROR: Invalid allowance! Please enter a positive integer for the allowance.`             |
|                                                                  |                                                                                                   |                                                                                                       |


## INFO Messages
If a command is executed successfully, the corresponding info message is printed.
Afterwards, the input prompt is shown again and the user can enter a new command.
The info messages are shown in the output examples in the section [Milestone_1](Milestone_1.md#commands)


## BEISPIELAUSGABE FÜR MILESTONE 1

```
Enter command: deposit
ERROR: Invalid number of parameters!
Enter command: withdraw
ERROR: Invalid number of parameters!
Enter command: transfer
ERROR: Invalid number of parameters!
Enter command: logout
ERROR: You must be logged in to execute this command!
Enter command: deposit 10
ERROR: You must be logged in to execute this command!
Enter command: withdraw 10
ERROR: You must be logged in to execute this command!
Enter command: login Amalia Glenn
ERROR: Invalid number of parameters!
Enter command: login Amalia Glenn CB23000022219067
INFO: Successfully logged into the CreditAccount of Amalia Glenn.
---
Welcome Amalia Glenn.
---

Enter command: deposit
ERROR: Invalid number of parameters!
Enter command: deposit 50
INFO: 50.0€ added to your account.

Enter command: deposit 100
INFO: 100.0€ added to your account.

Enter command: deposit A
ERROR: Invalid parameter type!
Enter command: deposit -1
ERROR: Amount must be a positive number!
Enter command: deposit 50
INFO: 50.0€ added to your account.

Enter command: withdraw
ERROR: Invalid number of parameters!
Enter command: withdraw A
ERROR: Invalid parameter type!
Enter command: withdraw -1
ERROR: Amount must be a positive number!
Enter command: withdraw 1ß
ERROR: Invalid parameter type!
Enter command: withdraw 10
INFO: 10.0€ withdrawn from your account.

Enter command: balance A
ERROR: Invalid number of parameters!
Enter command: balance -1
ERROR: Invalid number of parameters!
Enter command: balance
INFO: Your balance is 190.0 €.

Enter command: transfer A A
ERROR: Invalid parameter type!
Enter command: transfer
ERROR: Invalid number of parameters!
Enter command: transfer -10 CB23000082346568
ERROR: Amount must be a positive number!

Enter command: transfer 43 CB23000082346568
INFO: 43.0€ transferred to CB23000082346568.

Enter command: statement
Bank statements for account: CB23000022219067
Outgoing IBAN    | Ingoing IBAN     | Transaction Type  | Amount
-----------------+------------------+-------------------+-------
---------------- | CB23000022219067 | DEPOSIT           | 50.0 €
---------------- | CB23000022219067 | DEPOSIT           | 100.0 €
---------------- | CB23000022219067 | DEPOSIT           | 50.0 €
CB23000022219067 | ---------------- | CASH WITHDRAWAL   | -10.0 €
CB23000022219067 | CB23000082346568 | BANK TRANSFER     | -43.0 €

Enter command: logout
Enter command: login
ERROR: Invalid number of parameters!
Enter command: login Cian Grimes CB23000082346568
INFO: Successfully logged into the CheckingAccount of Cian Grimes.
---
Welcome Cian Grimes.
---

Enter command: balance
INFO: Your balance is 43.0 €.

Enter command: statement
Bank statements for account: CB23000082346568
Outgoing IBAN    | Ingoing IBAN     | Transaction Type  | Amount
-----------------+------------------+-------------------+-------
CB23000022219067 | CB23000082346568 | BANK TRANSFER     | 43.0 €

Enter command: logout
Enter command: exit
INFO: Exiting program...

Process finished with exit code 0

```

## BEISPIELAUSGABE FÜR MILESTONE 2
```
Enter command: open Moritz Wenger CheckingAccount
ERROR: Invalid number of parameters!
Enter command: open Moritz Wenger CheckingAccount 100
Enter date of birth <DD.MM.YYYY>: 01.01.2000
INFO: Account created successfully!
INFO: Your IBAN is CB23000009600319 and your BIC is CBKAPF23.

Enter command: login Moritz Wrrrrr CB23000009600319
ERROR: Invalid username!
Enter command: login MRRR Wenger CB23000009600319
ERROR: Invalid username!
Enter command: login Moritz Wenger CB23
ERROR: Invalid IBAN!
Enter command: login Moritz Wenger CB23000009600319
INFO: Successfully logged into the CheckingAccount of Moritz Wenger.
---
Welcome Moritz Wenger.
---

Enter command: deposit AAA
ERROR: Invalid parameter type!
Enter command: deposit -100
ERROR: Amount must be a positive number!
Enter command: deposit 100
INFO: 100.0€ added to your account.

Enter command: balance S
ERROR: Invalid number of parameters!
Enter command: balance
INFO: Your balance is 100.0 €.

Enter command: withdraw 500000
ERROR: You do not have enough funds to withdraw 500000.0 €!
Enter command: withdraw A
ERROR: Invalid parameter type!
Enter command: withdraw -10
ERROR: Amount must be a positive number!
Enter command: withdraw 50
INFO: 50.0€ withdrawn from your account.

Enter command: deposit 20
INFO: 20.0€ added to your account.

Enter command: deposit 30
INFO: 30.0€ added to your account.

Enter command: deposit 50
INFO: 50.0€ added to your account.

Enter command: withdraw 10
INFO: 10.0€ withdrawn from your account.

Enter command: statement
Bank statements for account: CB23000009600319
Outgoing IBAN    | Ingoing IBAN     | Transaction Type  | Amount
-----------------+------------------+-------------------+-------
---------------- | CB23000009600319 | DEPOSIT           | 100.0 €
CB23000009600319 | ---------------- | CASH WITHDRAWAL   | -50.0 €
---------------- | CB23000009600319 | DEPOSIT           | 20.0 €
---------------- | CB23000009600319 | DEPOSIT           | 30.0 €
---------------- | CB23000009600319 | DEPOSIT           | 50.0 €
CB23000009600319 | ---------------- | CASH WITHDRAWAL   | -10.0 €

Enter command: logout
Enter command: exit
INFO: Exiting program...

Process finished with exit code 0
```
