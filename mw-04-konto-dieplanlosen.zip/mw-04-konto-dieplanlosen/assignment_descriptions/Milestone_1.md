# Milestone 1

---
The goal of Milestone 1 is to implement the basic structure needed for the program and create
some of the output to the console. This includes creating basic classes in an object-oriented strcutre based on your
design document.

> Hinweis: Die Aufgabenstellung ist in Englisch geschrieben, da dies zur Übung wichtig ist und
> in der Arbeitswelt nicht nur bei zugewiesenen Aufgaben auftritt, sondern auch bei Dokumentationen
> oder Framework Beschreibungen üblich ist.
>
> Solltest du Schwierigkeiten beim Verstehen der Beschreibung haben
> verwende DEEPL oder CHATGPT (AI basierte Übersetzungstools / Sprachmodelle) um dir die Aufgabenstellung stückweise
> zu übersetzen. Ansonsten kannst du jederzeit deine/n Trainer/in fragen :D

The program consists of the following steps:
1. [Reading & storing the provided data](#file-reading)
    - [Person](#person)
    - [Account](#account)

2. The main functionality, which consists of the following [Commands](#commands):
    - [Help](#help)
    - [Exit](#exit)
    - [Login](#login)
    - [Deposit](#deposit)
    - [Withdraw](#withdraw)
    - [Balance](#balance)
    - [Statement](#statement)
    - [Transfer](#transfer)
    - [Logout](#logout)
3. Advanced functionality (see [Milestone 2](Milestone_2.md#open))

4. Error handling (see [Milestone 2](Milestone_2.md#error-messages))

6. BONUS: (see [Milestone 2](Milestone_2.md#bonus-task))

---
## Provided Classes
The Class [Main](../src/main/java/Main.java) is the entry point of the program.
It contains the main method, which is the first method that is called when the program is run.
The main method already has some code in it, which you can but should not change.

Further the class [ReadFiles](../src/main/java/ReadFiles.java) is provided partially.
The constructor and necessary reading objects are already implemented.
They should be used to read the data from the given files.

---
## Classes to Implement
All class attributes for your program should be stored as `private`.
This means that they can only be accessed from within the class itself.
To ensure that the attributes can still be accessed from outside the class, you should create getter and setter methods.

All class method can and should be created as `public`.
This is important so that the methods can be accessed from outside the class.

When creating objects from a class, you should use the constructor of the class.

When trying to read data from an object use its getter methods.

When trying to write data to an object use its setter methods.

---
You can create additional classes if you want to, however the following classes are required:
- Main (already provided)
- [ReadFiles](#file-reading) (partially provided)
- [Person](#person)
- [Account](#account)
    - CheckingAccount
    - SavingsAccount
    - CreditAccount
- [Transaction](#transaction)
- DataBase
- CommandLines
- Command

### Person
A person has a the following private attributes:
- first_name_ (String)
- last_name_ (String)
- date_of_birth_ (Stringof format DD.MM.YYYY).

The values should be initialised in the constructor and can be accessed using getter methods.

### Account
An account has the following private attributes:
- owner_ (Person)
- iban_ (String)
- bic_ (String)
- type_ (String)
- balance_ (double)
- overdraft_limit_ (double)
- transactions_ (List of Transaction)

An account also inherits all its parameters to the subclasses
- CheckingAccount
- SavingsAccount
- CreditAccount

> Note that the subclasses do not have any additional attributes.
> They are only used to differentiate between the different account types.
> Also note that the subclasses share the same methods with the superclass Account.

> Hint: A Savingsaccount should not have any overdraft limit. To make it easier
> it is absolutely ok to initialise the overdraft limit of a Savingsaccount with the value 0.

### Transaction
A transaction has the following private attributes:
- outgoing_iban_ (String)
- incoming_iban_ (String)
- amount_ (double)
- transaction_type_ (String)

> Hint: To ensure an Object oriented design, try to use constructor overloading for the class Transaction.

---
## File Reading
The data for the program is provided in the files:
- [Short Config](../files/config_01.txt)
- [Long Config](../files/config_02.txt)
- [Faulty Config](../files/bad_config.txt)

The program is started with the path to one of these files as a parameter in the main class.
> For testing you can change this parameter but the provided valid files are structured the same way.

Your program should be able to read all valid config files.

### Parsing the File
The config file is a text file. If the config file starts with the correct string `CODERSBAY\n`,
you can assume that it is formatted correctly and only contains valid information.
Further checks of the file are not necessary.

If the file can not be read because it does not exist or the path is incorrect (or it is not formatted correctly),
the program should exit with the corresponding
error message found in [Error Messages](../assignment_descriptions/Milestone_2.md#error-messages).

Following the identifier string, the file contains the headings that are used to identify the different columns
of the file and the data that is stored in them. The headings are separated by a comma and a space (", ").
The headings should be used in [Milestone 2](../assignment_descriptions/Milestone_2.md) to write the data back to the
specified files.

After the headings, the file contains the data.
Each data line contains the full name of a person seperated by a space,
followed by their birthday in the format `DD.MM.YYYY`.
After the birthday, an `X` indicates that the person does NOT have an account of the type specified in the heading.
If the person has an account, the account number is specified instead of the `X`.
> The account number or "IBAN" is a string of 16 characters. The format of a given IBAN always follows the pattern:
> `CB230000` followed by `8` random digits between 0 and 9. For example `CB23000012345678`.
> **WARNING: The IBAN is unique for each person and account type**.

All data points are separated by a comma and a space (", "). The data lines are separated by a new line character ("\n").

### Storing the Data
The data should be stored in a way that allows easy access to the data. For this purpose, you should create a class
for each person and a class for each account type. The classes should be structured in a way that allows you to
access the data easily. For example, you could create a class `Person` that contains the name and birthday of a person
and a list of accounts. The class `Account` could contain the account number and the balance of the account.

A different approch would be to create a class `Person` that contains the name and birthday of a person and a class for
each account type that contains the account number and the balance of the account. Additionally a class `DataBase` could
store all the `Person` and `Account` objects. This would allow you to access the data by using the name of the person.
> Note that this is just an example. You can structure the classes however you want. However the classes `Person` and
> `Account` are described in more detail under [Person](#person) and [Account](#account).
---


## Inputs and Outputs
The following guidelines apply to ***ALL COMMANDS AND THEIR RESPECTIVE INPUTS***

If the program reads a number as a datapoint it should only be possible to enter a number with maximum two decimal places.
> Valid inputs could be `12.34`, `12.3`, `12`, `12.00`, `12.0`, `12.`, `12.00`, etc...

If not otherwise specified, the output of numbers should be formatted with two decimal places.
> For example `12.34` instead of `12.3456789`.
> ***DO NOT USE*** rounding functions because they can lead to errors in the calculations.

---
## Commands
If nothing or only whitespaces are entered, the input prompt should be shown again and the program should wait for
the next input. A command can have 0 or more parameters. The parameters are separated by a space (" ").
> Note that the commands are not case sensitive. This means that the commands can be entered in any case and the
> program should still work. For example `exit`, `EXIT`, `eXiT`, etc... should still work.

An example for a valid command would be `login Firstname Lastname CB23000012345678`.
This command would log the user with the name `Firstname Lastname` into the account with the number `CB23000012345678`.

> ***A command can only be executed if this does not violate the rules of the program or the rules of the command.***
> If the command is not entered correctly (e.g. incorrect number/order/type of parameters) or it violates the rules of the
> the program in any other way, then
> - the corresponding error message is printed (see [Error Messages](../assignment_descriptions/Milestone_2.md#error-messages)) **VERY IMPORTANT**
> - nothing is changed in the program
> - the input prompt is shown again and the program waits for the next input

## All valid commands and their individual rules are listed below.

---
### Exit
Terminates the program (return value 0).
- **Command:** `exit`
- **Parameters:** None
- The command `exit` can be entered at any time and should always terminate the program with the return value 0.
  The output after exiting the program should be the following text:
```
INFO: Exiting program...
```
followed by the compiler specific exit message
```Process finished with exit code 0``` (printed automatically)

---
### Help
Outputs the following help text. This command has no rules apart from the format of the output and the general rules described above.
- **Command:** `help`
- **Parameters:** None
- The command `help` can be entered at any time and should always output the following text:
```
Available commands:
--------------------------------------------------------------------------------
login <firstname> <lastname> <IBAN>
	 - Logs in to the system with the specified username and IBAN.
	 - The username consists of a first name and a last name, separated by a space.
	 
deposit <amount>
	 - Deposits the specified amount to the account.
	   The amount must be a positive number.
	   
withdraw <amount>
	 - Withdraws the specified amount from the account.
	   The amount must be a positive number.
	   
statement <iban>
	 - Prints the bank statement of the specified account.
	 
balance <iban>
	 - Prints the current balance of the specified account.
	 
logout
	 - Logs the current account out of the system.
	 
transfer <amount> <iban>
	 - Transfers the specified amount from your account to the specified IBAN.
	 
open <Firstname> <Lastname> <account_type> <maximum_debt_amount>
	 - Opens a new account of the specified type with the specified maximum debt amount.
	   Account types: "CheckingAccount", "CreditAccount", "SavingsAccount"
	   For SavingsAccount enter 0 for <maximum_debt_amount>.
	 WARNING: If user is already logged in use:
		open <account_type> <maximum_debt_amount>
		
close <iban>
	 - Closes the specified account.
	 
exit
	 - Exits the program.
	 
help
	 - Prints this help message.
--------------------------------------------------------------------------------
```
> After the help text is printed, the input prompt should be shown again and the program should wait for the next input.
---
### Login
Logs in to the system with the specified username and IBAN.
- **Command:** `login <firstname> <lastname> <IBAN>`
- **Parameters:**
    - `<firstname>`: The first name of the user.
    - `<lastname>`: The last name of the user.
    - `<IBAN>`: The IBAN of the account that the user wants to log in to.
- **Rules:**
    - The user can only log in if the account exists and the name of the user matches the name of the account.
    - If the user is already logged in, the user can only logout and login again with a different account.

A successful login should print the following output:
```
INFO: Successfully logged into the <account_type> of <firstname> <lastname>.
---
Welcome <firstname> <lastname>.
---
```
> Note that ```<account_type>``` and ```<firstname> <lastname>``` should be replaced with the corresponding values.

After the output is printed, the input prompt should be shown again and the program should wait for the next input.

If the user is successfully logged in an example for the corresponding output would be:
```
Enter command: login Amalia Glenn CB23000022219067
INFO: Successfully logged into the CreditAccount of Amalia Glenn.
---
Welcome Amalia Glenn.
---
Enter command: 
```

---
### Deposit
Deposits the specified amount to the account.
- **Command:** `deposit <amount>`
- **Parameters:**
    - `<amount>`: The amount that should be deposited.
- **Rules:**
    - The user must be logged in.
    - The amount must be a positive number.
      A successful deposit should print the following output:
```
INFO: Successfully deposited <amount> to your account.
```
> Note that ```<amount>``` should be replaced with the corresponding value.

---

### Withdraw
Withdraws the specified amount from the account.
- **Command:** `withdraw <amount>`
- **Parameters:**
    - `<amount>`: The amount that should be withdrawn.
- **Rules:**
    - The user must be logged in.
    - The amount must be a positive number.
- The user must have enough money in their account to withdraw the specified amount
  **or** have enough allowance to afford a withdrawal of given amount.

A successful withdrawal should print the following output:
```
INFO: Successfully withdrawn <amount> from your account.
```
> Note that ```<amount>``` should be replaced with the corresponding value.

---
### Balance
Displays the accounts current balance.
- **Command:** `balance`
- **Parameters:** None
- **Rules:**
    - The user must be logged in.

A successful balance check should print the following output:
```
INFO: Your balance is: <balance> €
```
> Note that ```<balance>``` should be replaced with the corresponding value.
>
---
### Statement
Prints the bank statement containing all transactions of the logged in account.
- **Command:** `statement`
- **Parameters:** None
- **Rules:**
    - The user must be logged in.

The format of a bank statement is best described with an example:
```
INFO: Printing bank statement for account: CB23000022219067

Outgoing IBAN    | Ingoing IBAN     | Transaction Type  | Amount
-----------------+------------------+-------------------+-------
---------------- | CB23000022219067 | DEPOSIT           | 100.00 €
---------------- | CB23000022219067 | DEPOSIT           | 50.00 €
CB23000022219067 | ---------------- | CASH WITHDRAWAL   | -40.00 €
CB23000022219067 | CB23000095654823 | BANK TRANSFER     | -60.00 €
```

A bank statement should contain the following information:
- The outgoing IBAN is the IBAN of the account that the money was transferred/withdrawn from.
- The ingoing IBAN is the IBAN of the account that the money was transferred/deposited to.
- The transaction type is the type of the transaction. Possible types are:
    - `DEPOSIT`: The money was deposited to the account.
    - `CASH WITHDRAWAL`: The money was withdrawn from the account.
    - `BANK TRANSFER`: The money was transferred from the account to another account.
- The amount is the amount of money that was transferred/deposited/withdrawn.
    - The amount should be displayed with 2 decimal places.
    - The amount should be displayed with the currency symbol (€).
    - The amount should be displayed with a minus sign (-) if the transaction was a withdrawal or a bank transfer.

> Formatting tips:
> instead of copying the number of "-" characters try to calculate the number of needed whitespaces
> when printing something. Look at the number of characters needed for the longest string found in
> a column above. This should give you an idea to ensure your code still works, if for example a new
> transaction type is implemented. (Code Durability).

> Hint: You should use the Transaction class to store the information of a transaction.
>
> Everytime a transaction is made (deposit, withdrawal, bank transfer), you can create a new Transaction object
> and add it to a list of transactions.
---
### Logout
Logs the current account out of the system.
- **Command:** `logout`
- **Parameters:** None
- **Rules:**
    - The user must be logged in.

A successfull logout should not print any output.
Instead the input prompt should be shown again and the program should wait for the next input.

---
### Transfer
Transfers the specified amount from your account to the specified IBAN.
- **Command:** `transfer <amount> <iban>`
- **Parameters:**
    - `<amount>`: The amount that should be transferred.
    - `<iban>`: The IBAN of the account that the money should be transferred to.
- **Rules:**
    - The user must be logged in.
    - The amount must be a positive number.
    - The user must have enough money in their account to transfer the specified amount
      **or** have enough allowance to afford a transfer of given amount.
    - The IBAN must be valid (i.e. the account must exist).
    - The IBAN must not be the same as the IBAN of the account that the money is transferred from.

A successfull bank transfer should print the following output:
```
INFO: <amount> € transferred to <Receiving_IBAN>.
```
> Note that ```<amount>``` and ```<Receiving_IBAN>``` should be replaced with the corresponding values.
> <amount> should be displayed with 2 decimal places and the currency symbol (€).

---

